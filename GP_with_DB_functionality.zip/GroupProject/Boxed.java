/*
Authors: John Morrissey, Erin Logush, and Param Ektare
Date: 12/7/2017
Assignment: Group Project Pt. 2
Purpose: This program demonstrates how to create a GUI to gather multiple inputs from the user and
use them to create objects which the user can later manipulate.
 */
package GroupProject;
import java.util.ArrayList;

public class Boxed extends Item {
    public String description;
    public int categoryID = 4;
    
    //constructor
    public Boxed (String itemName, String itemDescription, double itemCost,
            double itemRetail, int itemQty, String itemCategory) {
        //send to part Item
        super(itemName, itemDescription, itemCost, itemRetail, itemCategory, itemQty);
        this.description = "Boxed";
        this.categoryID = 4;
    }
    
    @Override
    public String toString() {
        //print the description of the relevant object
        String printDescription = "";
        printDescription += super.toString() + " | " + this.description;
        return printDescription;
    }
}
