
package GroupProject;

public class Bagged extends Item {
    public String description;
    
    public Bagged (String itemName, String itemDescription, double itemCost,
            double itemRetail, int itemQty, String itemCategory) {
        super(itemName, itemDescription, itemCost, itemRetail, itemCategory, itemQty);
        this.description = "Bagged";
    }
    
    //Overloaded Constructor for Edit Item
    public Bagged (int itemID, String itemName, String itemDescription, double itemCost, double itemRetail, int itemQty, String itemCategory)
    {
        super(itemID, itemName, itemDescription, itemCost, itemRetail, itemCategory, itemQty);
        this.description = "Bagged";
    }
    
    @Override
    public String toString() {
        //print the description of the relevant object
        String printDescription = "";
        printDescription += super.toString() + " | " + this.description;
        return printDescription;
    }
    
}


