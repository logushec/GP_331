/*
Authors: John Morrissey, Erin Logush, and Param Ektare
Date: 12/7/2017
Assignment: Group Project Pt. 2
Purpose: This program demonstrates how to create a GUI to gather multiple inputs from the user and
use them to create objects which the user can later manipulate.
 */
package GroupProject;

public class MeatDairy extends Item {
    public String description;
    
    //constructor
    public MeatDairy (String itemName, String itemDescription, double itemCost,
            double itemRetail, int itemQty, String itemCategory) {
        //send to parent Item
        super(itemName, itemDescription, itemCost, itemRetail, itemCategory, itemQty);
        this.description = "Meats/Dairy";
    }
    
    //Overloaded Constructor for Edit Item
    public MeatDairy (int itemID, String itemName, String itemDescription, double itemCost, double itemRetail, int itemQty, String itemCategory)
    {
        //send to parent item
        super(itemID, itemName, itemDescription, itemCost, itemRetail, itemCategory, itemQty);
        this.description = "Meat/Dairy";
    }
    
    @Override
    public String toString() {
        //print the description of the relevant object
        String printDescription = "";
        printDescription += super.toString() + " | " + this.description;
        return printDescription;
    }
    
}
