/*
Authors: John Morrissey, Erin Logush, and Param Ektare
Date: 12/7/2017
Assignment: Group Project Pt. 2
Purpose: This program demonstrates how to create a GUI to gather multiple inputs from the user and
use them to create objects which the user can later manipulate.
 */
package GroupProject;

import java.util.ArrayList;

public class Item {
    public static ArrayList<Item> itemList = new ArrayList<>();
    public static int inventoryCount = 0;
    public double itemCost;
    public String itemDescription;
    public int itemID;
    public String category;
    public String itemName;
    public int itemQty;
    public double itemRetail;
    public static int nextID = 0;
    
    public Item(String itemName, String itemDescription, double itemCost, double itemRetail, String category, int itemQty)
    {
        //set values to the relevant Item object
        this.itemCost = itemCost;
        this.itemDescription = itemDescription;
        this.itemName = itemName;
        this.itemRetail = itemRetail;
        this.itemQty = itemQty;
        this.category = category;
        inventoryCount += itemQty; //increase the num in inventory based upon 
        this.itemID  = nextID;
    }
    
    // Overloaded Constructor for Editing Items
    public Item(int itemID, String itemName, String itemDescription, double itemCost, double itemRetail, String category, int itemQty)
    {
        //set values to the relevant Item object
        this.itemCost = itemCost;
        this.itemDescription = itemDescription;
        this.itemName = itemName;
        this.itemRetail = itemRetail;
        this.itemQty = itemQty;
        this.category = category;
        inventoryCount += itemQty; //increase the num in inventory based upon 
        this.itemID  = itemID;
        itemList.remove(itemID);
    }
    
    //print out after Item is added
    public static String addToInventory(Item inventoryItem)
    {
        itemList.add(inventoryItem);
        nextID++;
        return ("Added: \n" + itemList.get(nextID - 1).toString());
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        //print the description of the relevant object
        String printDescription = "";
        printDescription += "\nID #: " + this.itemID + " | Item Name: " + this.itemName + " | Item Description: " + this.itemDescription + "\n" +
                " Item Cost: $" + this.itemCost + " | Retail Price: $" + this.itemRetail + " | Quantity: " + this.itemQty ;
        return printDescription;
    }
    
    public double getItemCost()
    {
        return this.itemCost;
    }
    
    public double getItemRetail()
    {
        return this.itemRetail;
    }
    
    public void setItemCost(double itemCost)
    {
        this.itemCost = itemCost;
    }
    
    public void setItemName(String itemName)
    {
        this.itemName = itemName;
    }
    
    public void setItemQty(int itemQty)
    {
        this.itemQty = itemQty; //this needs more code to update the amount of total we have in inventory
    }
    
    public void setItemRetail(double itemRetail)
    {
        this.itemRetail = itemRetail;
    }
    
    public void setItemDescription (String itemDescription)
    {
        this.itemDescription = itemDescription;
    }
    
}

